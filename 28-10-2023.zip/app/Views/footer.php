<script src="public/js/cdn.jsdelivr.net_npm_sweetalert2@11.js"></script>
<script src="public/js/bootstrap.bundle.min.js"></script>
<script src="public/js/code.jquery.com_jquery-3.7.1.js"></script>
</body>

</html>