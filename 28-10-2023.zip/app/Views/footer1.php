<footer id="colophon" class="site-footer thim-footer-therapist">
    <div class="copyright-area">
        <div class="container">
            <div class="copyright-content">
                <div class="row">
                    <div class="col-sm-6 copyright-msg">Development Management Institute - All rights reserved  &copy; 20<?php echo date('y');?></div>
                    <!-- <div class="col-sm-6 copyright-msg" style="text-align: right;"><a href="https://www.linkedin.com/in/chandra-kishore-g-4044671bb/" target="_blank">Designed and Developed by Chandra Kishor Gupta</a></div> -->
                </div>
            </div>
        </div>
    </div>
</footer>
</div>
</div>
<a href="#" id="back-to-top">
    <i class="fa fa-chevron-up"></i>
</a>
</div>
<script>
    window.RS_MODULES = window.RS_MODULES || {};
    window.RS_MODULES.modules = window.RS_MODULES.modules || {};
    window.RS_MODULES.waiting = window.RS_MODULES.waiting || [];
    window.RS_MODULES.defered = false;
    window.RS_MODULES.moduleWaiting = window.RS_MODULES.moduleWaiting || {};
    window.RS_MODULES.type = 'compiled';
</script>
<div class="gallery-slider-content"></div>
<script data-cfasync="true" type="text/javascript">
    (function($) {
        'use strict';
        $(document).
        on('click',
            'body:not(".logged-in") .enroll-course .button-enroll-course, body:not(".logged-in") .purchase-course:not(".guest_checkout") .button, body:not(".logged-in") .purchase-course:not(".guest_checkout,.learn-press-pmpro-buy-membership") .button',
            function(e) {
                e.preventDefault();
                $(this).
                parent().
                find('[name="redirect_to"]').
                val('../account/index95cf.html?redirect_to=https://coaching.thimpress.com/demo-therapist/about-me/?enroll-course=5644');
                var redirect = $(this).parent().find('[name="redirect_to"]').val();
                window.location = redirect;
            });
    })(jQuery);
</script>
<link rel="stylesheet" id="mo-openid-sl-wp-font-awesome-css" href="public/wp-content/plugins/miniorange-login-openid/includes/css/mo-font-awesome.mine35d.css?ver=6.3.2" type="text/css" media="all" />
<link rel="stylesheet" id="mo-wp-style-icon-css" href="public/wp-content/plugins/miniorange-login-openid/includes/css/mo_openid_login_iconsdae3.css?version=7.6.6&amp;ver=6.3.2" type="text/css" media="all" />
<link rel="stylesheet" id="mo-wp-bootstrap-social-css" href="public/wp-content/plugins/miniorange-login-openid/includes/css/bootstrap-sociale35d.css?ver=6.3.2" type="text/css" media="all" />
<link rel="stylesheet" id="mo-wp-bootstrap-main-css" href="public/wp-content/plugins/miniorange-login-openid/includes/css/bootstrap.min-previewe35d.css?ver=6.3.2" type="text/css" media="all" />
<link rel="stylesheet" id="tiptipcss-css" href="public/wp-content/plugins/pricing-table-plus/css/site/tipTipe35d.css?ver=6.3.2" type="text/css" media="all" />
<link rel="stylesheet" id="rs-plugin-settings-css" href="public/wp-content/plugins/revslider/public/assets/css/rs6627e.css?ver=6.6.14" type="text/css" media="all" />
<script type="text/javascript" src="public/wp-content/plugins/learnpress-wishlist/assets/js/wishlista5a7.js?ver=652e4748a5e2f" id="lp-course-wishlist-js"></script>
<script type="text/javascript" src="public/wp-content/plugins/contact-form-7/includes/swv/js/indexf658.js?ver=5.8.1" id="swv-js"></script>
<script type="text/javascript" src="public/wp-content/plugins/contact-form-7/includes/js/indexf658.js?ver=5.8.1" id="contact-form-7-js"></script>
<script type="text/javascript" src="public/wp-content/plugins/tp-chameleon/assets/tp-chameleon.min8308.js?ver=2.0.3.1" id="tp-chameleon-js"></script>
<script type="text/javascript" src="public/wp-includes/js/jquery/ui/core.min3f14.js?ver=1.13.2" id="jquery-ui-core-js"></script>
<script type="text/javascript" src="public/wp-includes/js/underscore.mind584.js?ver=1.13.4" id="underscore-js"></script>
<script type="text/javascript" src="public/wp-includes/js/wp-util.mine35d.js?ver=6.3.2" id="wp-util-js"></script>
<script type="text/javascript" src="public/wp-includes/js/backbone.min330a.js?ver=1.4.1" id="backbone-js"></script>
<script type="text/javascript" src="public/wp-content/plugins/wp-events-manager/inc/libraries/countdown/js/jquery.plugin.mine35d.js?ver=6.3.2" id="wpems-countdown-plugin-js-js"></script>
<script type="text/javascript" src="public/wp-content/plugins/wp-events-manager/inc/libraries/countdown/js/jquery.countdown.mine35d.js?ver=6.3.2" id="wpems-countdown-js-js"></script>
<script type="text/javascript" src="public/wp-content/plugins/wp-events-manager/inc/libraries/magnific-popup/js/jquery.magnific-popup.mincc91.js?ver=2.1.8" id="wpems-magnific-popup-js-js"></script>
<script type="text/javascript" src="public/wp-content/plugins/wp-events-manager/assets/js/frontend/events.mine35d.js?ver=6.3.2" id="wpems-frontend-js-js"></script>
<script type="text/javascript" src="public/wp-content/plugins/thim-elementor-kit/build/frontende916.js?ver=1.1.7.3" id="thim-ekit-frontend-js"></script>
<script type="text/javascript" src="public/wp-content/plugins/elementor/assets/js/webpack.runtime.min33f1.js?ver=3.16.5" id="elementor-webpack-runtime-js"></script>
<script type="text/javascript" src="public/wp-content/plugins/elementor/assets/js/frontend-modules.min33f1.js?ver=3.16.5" id="elementor-frontend-modules-js"></script>
<script type="text/javascript" src="public/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min05da.js?ver=4.0.2" id="elementor-waypoints-js"></script>
<script id="elementor-frontend-js-before" type="text/javascript">
    var elementorFrontendConfig = {
        "environmentMode": {
            "edit": false,
            "wpPreview": false,
            "isScriptDebug": false
        },
        "i18n": {
            "shareOnFacebook": "Share on Facebook",
            "shareOnTwitter": "Share on Twitter",
            "pinIt": "Pin it",
            "download": "Download",
            "downloadImage": "Download image",
            "fullscreen": "Fullscreen",
            "zoom": "Zoom",
            "share": "Share",
            "playVideo": "Play Video",
            "previous": "Previous",
            "next": "Next",
            "close": "Close",
            "a11yCarouselWrapperAriaLabel": "Carousel | Horizontal scrolling: Arrow Left & Right",
            "a11yCarouselPrevSlideMessage": "Previous slide",
            "a11yCarouselNextSlideMessage": "Next slide",
            "a11yCarouselFirstSlideMessage": "This is the first slide",
            "a11yCarouselLastSlideMessage": "This is the last slide",
            "a11yCarouselPaginationBulletMessage": "Go to slide"
        },
        "is_rtl": false,
        "breakpoints": {
            "xs": 0,
            "sm": 480,
            "md": 768,
            "lg": 1025,
            "xl": 1440,
            "xxl": 1600
        },
        "responsive": {
            "breakpoints": {
                "mobile": {
                    "label": "Mobile Portrait",
                    "value": 767,
                    "default_value": 767,
                    "direction": "max",
                    "is_enabled": true
                },
                "mobile_extra": {
                    "label": "Mobile Landscape",
                    "value": 880,
                    "default_value": 880,
                    "direction": "max",
                    "is_enabled": true
                },
                "tablet": {
                    "label": "Tablet Portrait",
                    "value": 1024,
                    "default_value": 1024,
                    "direction": "max",
                    "is_enabled": true
                },
                "tablet_extra": {
                    "label": "Tablet Landscape",
                    "value": 1200,
                    "default_value": 1200,
                    "direction": "max",
                    "is_enabled": false
                },
                "laptop": {
                    "label": "Laptop",
                    "value": 1366,
                    "default_value": 1366,
                    "direction": "max",
                    "is_enabled": false
                },
                "widescreen": {
                    "label": "Widescreen",
                    "value": 2400,
                    "default_value": 2400,
                    "direction": "min",
                    "is_enabled": false
                }
            }
        },
        "version": "3.16.5",
        "is_static": false,
        "experimentalFeatures": {
            "e_dom_optimization": true,
            "e_optimized_assets_loading": true,
            "additional_custom_breakpoints": true,
            "landing-pages": true
        },
        "urls": {
            "assets": "https:\/\/coaching.thimpress.com\/demo-therapist\/wp-content\/plugins\/elementor\/assets\/"
        },
        "swiperClass": "swiper-container",
        "settings": {
            "page": [],
            "editorPreferences": []
        },
        "kit": {
            "active_breakpoints": ["viewport_mobile", "viewport_mobile_extra", "viewport_tablet"],
            "global_image_lightbox": "yes",
            "lightbox_enable_counter": "yes",
            "lightbox_enable_fullscreen": "yes",
            "lightbox_enable_zoom": "yes",
            "lightbox_enable_share": "yes",
            "lightbox_title_src": "title",
            "lightbox_description_src": "description"
        },
        "post": {
            "id": 5644,
            "title": "About%20me%20-%20Demo%20Therapist%20Coaching",
            "excerpt": "",
            "featuredImage": false
        }
    };
</script>
<script type="text/javascript" src="public/wp-content/plugins/elementor/assets/js/frontend.min33f1.js?ver=3.16.5" id="elementor-frontend-js"></script>
<script type="text/javascript" src="public/wp-includes/js/dist/vendor/wp-polyfill-inert.min0226.js?ver=3.1.2" id="wp-polyfill-inert-js"></script>
<script type="text/javascript" src="public/wp-includes/js/dist/vendor/regenerator-runtime.min8fa4.js?ver=0.13.11" id="regenerator-runtime-js"></script>
<script type="text/javascript" src="public/wp-includes/js/dist/vendor/wp-polyfill.min2c7c.js?ver=3.15.0" id="wp-polyfill-js"></script>
<script type="text/javascript" src="public/wp-includes/js/dist/hooks.min2ebd.js?ver=c6aec9a8d4e5a5d543a1" id="wp-hooks-js"></script>
<script type="text/javascript" src="public/wp-includes/js/dist/i18n.minf92f.js?ver=7701b0c3857f914212ef" id="wp-i18n-js"></script>
<script id="wp-i18n-js-after" type="text/javascript">
    wp.i18n.setLocaleData({
        'text direction\u0004ltr': ['ltr']
    });
</script>
<script type="text/javascript" src="public/wp-includes/js/dist/url.min3338.js?ver=8814d23f2d64864d280d" id="wp-url-js"></script>
<script type="text/javascript" src="public/wp-includes/js/dist/api-fetch.min471f.js?ver=0fa4dabf8bf2c7adf21a" id="wp-api-fetch-js"></script>
<script type="text/javascript" src="public/wp-content/plugins/thim-elementor-kit/build/widgetse916.js?ver=1.1.7.3" id="thim-ekit-widgets-js"></script>
<script type="text/javascript" src="public/wp-content/themes/coaching/assets/js/libs/bootstrap.mina6f4.js?ver=3.7.1.7" id="thim-bootstrap-js"></script>
<script type="text/javascript" src="public/wp-content/themes/coaching/assets/js/libs/theia-sticky-sidebar.mina6f4.js?ver=3.7.1.7" id="theia-sticky-sidebar-js"></script>
<script type="text/javascript" src="public/wp-content/themes/coaching/assets/js/libs/cookie.mina6f4.js?ver=3.7.1.7" id="thim-cookie-js"></script>
<script type="text/javascript" src="public/wp-content/themes/coaching/assets/js/libs/jquery.event.movea6f4.js?ver=3.7.1.7" id="thim-jquery-event-move-js"></script>
<script type="text/javascript" src="public/wp-content/themes/coaching/assets/js/libs/thim-contentslidera6f4.js?ver=3.7.1.7" id="thim-jquery-contentslider-js"></script>
<script type="text/javascript" src="public/wp-content/themes/coaching/assets/js/libs/smooth_scroll.mina6f4.js?ver=3.7.1.7" id="smooth-scroll-js"></script>
<script type="text/javascript" src="public/wp-includes/js/imagesloaded.mineda1.js?ver=4.1.4" id="imagesloaded-js"></script>
<script type="text/javascript" src="public/wp-content/themes/coaching/assets/js/custom-script.mina6f4.js?ver=3.7.1.7" id="thim-custom-script-js"></script>
<script type="text/javascript" src="public/wp-content/plugins/miniorange-login-openid/includes/js/mo_openid_jquery.cookie.mine35d.js?ver=6.3.2" id="js-cookie-script-js"></script>
<script type="text/javascript" src="public/wp-content/themes/coaching/assets/js/libs/owl.carousel.mina6f4.js?ver=3.7.1.7" id="owl-carousel-js"></script>
<script type="text/javascript" src="public/wp-content/plugins/pricing-table-plus/js/site/jquery.tipTip.minifiede35d.js?ver=6.3.2" id="tiptipjs-js"></script>
<script type="text/javascript" id="siteorigin-panels-front-styles-js-extra">
    var panelsStyles = {
        "fullContainer": "body",
        "stretchRows": "1"
    };
</script>
<script type="text/javascript" src="public/wp-content/plugins/siteorigin-panels/js/styling.minc30a.js?ver=2.26.1" id="siteorigin-panels-front-styles-js"></script>
<script type="text/javascript">
    document.body.className = document.body.className.replace("siteorigin-panels-before-js", "");
</script>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        const slides = document.querySelectorAll('.carousel-slide');
        let currentSlide = 0;

        function showSlide(index) {
            slides.forEach((slide, i) => {
                slide.style.display = (i === index) ? 'block' : 'none';
            });
        }
        function nextSlide() {
            currentSlide = (currentSlide + 1) % slides.length;
            showSlide(currentSlide);
        }
        showSlide(currentSlide);
        setInterval(nextSlide, 3000);
    });
</script>
</body>

</html>