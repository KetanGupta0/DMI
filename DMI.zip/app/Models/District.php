<?php

namespace App\Models;

use CodeIgniter\Model;

class District extends Model
{
    protected $table = 'cities';
    protected $primaryKey = 'id';
}
