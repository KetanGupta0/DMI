<div class="content">
    <img class="page pg-en" src="public/img/page2.jpg" alt="English Content">
</div>

<div class="apply-container">
    <a href="form" class="btn btn-primary" style="width: fit-content !important; margin-bottom: 100px;">Apply Now</a>
</div>