<div class="container mt-3">
    <span class="tc">CERTIFICATE COURSE IN MANAGEMENT:<br> ENHANCING EMPLOYABILITY SKILLS</span>
</div>
<div class="container eContents">
    <p class="ti">
        <img class="eImageBox" src="public/img/gal1.jpg" alt="">
        <span style="padding: 0 0px 0 20px;">
        The cerficate programme will hone your technical and so skills to enhance your employability and higher educaon opportunies. Your need for such a programme is important because employers and higher educaon instutes think about these qualies highly and reward them. Also, you seek beer guidance to stay ahead of tough compeon by acquiring desired technical and so skills. DMI appreciates your need and the faculty at DMI has designed this cerficate programme as an outreach to help you gain by taking advantage of this opportunity. you will be learning from the best of the faculty at DMI.</span>
    </p>
    <p class="ti2">The cerficate programme helps you prepare for compeve examinaon and interviews like
Banking, SSC, Railway, CAT, MAT, XAT, CMAT, and more. It enables you to improve your Math,
English, Communicaon, IT and people Management skills.</p>
</div>